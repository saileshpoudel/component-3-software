﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TASK

{
    class ShapeIdentify
    {

        /// checking the type of shape

        /// <param name="shapeType"></param>
        /// <returns>return shape object </returns>
        public Interface1 GetShape(string shapeType)
        {
            if (shapeType == "circle")
            {
                return new Circle();
            }
            else if (shapeType == "rectangle")
            {
                return new Rectangle();
            }

            else if (shapeType == "triangle")
            {
                return new Triangle();
            }

            else if(shapeType=="square")
            {
                return new Square();
            }
            return null;
        }
    }
}
