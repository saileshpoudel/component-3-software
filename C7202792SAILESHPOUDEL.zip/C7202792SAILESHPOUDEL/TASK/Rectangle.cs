﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TASK

{
    public class Rectangle : Interface1
    {
        public int x, y, size, size1;
        public int texturestyle;


        public Color c1;

        /// <summary>
        /// this function will draw rectangle
        /// </summary>
        /// <param name="g"></param>
        public void Draw(Graphics g)
        {
            SolidBrush bb = new SolidBrush(c1);
            Pen p = new Pen(c1, 5);
            if (texturestyle == 0)
            {
                g.DrawRectangle(p, x, y, size, size1);
            }
            else
            {
                g.FillRectangle(bb, x, y, size, size1);
            }
        }

        /// Setting the required properties for rectangle

        /// <param name="texturestyle"></param>
        /// <param name="bb"></param>
        /// <param name="c1"></param>.
        /// <param name="list"></param>
        public void set(int texturestyle, Color c1, params int[] list)
        {
            this.texturestyle = texturestyle;
            this.c1 = c1;
            this.x = list[0];
            this.y = list[1];
            this.size = list[2];
            this.size1 = list[3];
        }
    }
}
